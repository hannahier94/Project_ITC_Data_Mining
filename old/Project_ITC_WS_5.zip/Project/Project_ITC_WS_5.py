import json
import CONSTANTS
import PARSER


def save_file(filename):
    """
    This function saves the file as a json file inside the folder that we are working on
    :param filename: Filename to create
    :return: json file
    """
    with open('result.json', 'w') as fp:
        json.dump(filename, fp)
        fp.close()


def main():
    saved = PARSER.html_data(CONSTANTS.URL, CONSTANTS.USER_AGENT_LIST, CONSTANTS.PAGES, CONSTANTS.KEYS)
    save_file(saved)
    print(len(saved['title']))


if __name__ == '__main__':
    main()
