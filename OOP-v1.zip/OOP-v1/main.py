import utils
from htmls import Htmls
from user_args import parse_args , UserInputs
import log_class

input_args = parse_args()
#global user_input
user_input = UserInputs(input_args)
log =  log_class.get_logger(console = user_input.console)

def main():
    """
    Directs script to correct function based on inputs
    """

    topics = user_input.apply_func()

    h = Htmls(topics, utils.POST_KEYS)
    print(topics)
    res = h.get_html_data(log)

    return res

res = main()
print(type(res), '\n\n')

print(res)