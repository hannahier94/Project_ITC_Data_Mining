"""
Create log class for log files
"""

import logging


class Log:

    LEVEL_DICT = {'DEBUG': logging.DEBUG,
                  'INFO': logging.INFO,
                  'WARNING': logging.WARNING,
                  'ERROR': logging.ERROR}

    __FORMAT = '%(asctime)s:%(levelname)s:%(name)s:%(message)s'
    __DTFRMT = '%m/%d/%Y %I:%M:%S %p'

    def __init__(self, console=False):
        """ Initialize logger info """

        self.console = console

        # General log info
        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(logging.DEBUG)
        self.formatter = logging.Formatter(self.__FORMAT , datefmt= self.__DTFRMT) #logging.basicConfig(format='%(asctime)s %(message)s',
        # Set log levels
        self.__set_debug()
        self.__set_info()

        if self.console:
           self.__add_console()


    def __set_debug(self):
        """ Create debug files """
        self.__file_handler = logging.FileHandler('full_logs.log')
        self.__file_handler.setFormatter(self.formatter)

        self.logger.addHandler(self.__file_handler)
        self.__file_handler.setLevel(logging.DEBUG)

    def __set_info(self):
        " Create Info level files "
        info_handler = logging.FileHandler('info_tst.log')
        info_handler.setFormatter(self.formatter)

        self.logger.addHandler(info_handler)
        self.logger.addHandler(info_handler)
        info_handler.setLevel(logging.INFO)

    def __add_console(self):

        """Add console logs if requested from user via user_args inputs"""
        stream_handler = logging.StreamHandler()
        self.logger.addHandler(stream_handler)
        stream_handler.setFormatter(self.formatter)

        for k,v in self.LEVEL_DICT.items():
            if k == self.console:
                stream_handler.setLevel(v)



        #self.logger.addHandler(logging.StreamHandler(sys.stdout))


def get_logger(console=False):
    logger = Log().logger
    return logger


