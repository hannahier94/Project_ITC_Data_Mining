"""

"""

from parser import Parser
from utils import USER_KEYS
from variables import Variables
from users import Users
#from log_class import Log
import time

class Htmls(Parser):
    
    def __init__(self, urls, keys, unfinished = True):
        Parser.__init__(self,urls,keys)
        self.forums = []
        self.info = {key: [] for key in self.keys} 
        self.unfinished = unfinished
        self.user_info = {k: [] for k in USER_KEYS} 
    
    def __repr__(self):
        return self
    
    def __str__(self):
        return str(self)
        
    def get_html_data(self,log):
        self.log = log
        for url in self.urls:
            while self.unfinished:
                #soup, posts = get_info.get_info(url)
                soup, posts = self.get_info(url, self.log)

                for post in posts:  # looping inside the information extracted in each page
                    var = Variables(post, self.info)
                    self.info = var.parse_info(logger=self.log)

                    user = Users(post, self.user_info)
                    self.user_info = user.get_user_info(logger=self.log)
                    global user_results
                    user_results = self.user_info


                for key in self.keys:  # updating the users dictionary
                    self.users[key] += self.info[key]
                    
                #for key in USER_KEYS:
                    #self.user[key] += self.user_info[key]

                #url, unfinished = next_url.next_url(url, soup, unfinished)

                url, self.unfinished = self.next_url(url, soup, self.unfinished, logger=self.log)

                time.sleep(self.sleeptime)
                
                self.forums.append(self.users)
            
        return self.forums

