import json
import CONSTANTS
import PARSER


def save_file(filename):
    with open('result.json', 'w') as fp:
        json.dump(filename, fp)
        fp.close()


def main():
    saved = PARSER.html_data(CONSTANTS.URL, CONSTANTS.USER_AGENT_LIST, CONSTANTS.PAGES, CONSTANTS.KEYS, CONSTANTS.THREADS)
    save_file(saved)


if __name__ == '__main__':
    main()
