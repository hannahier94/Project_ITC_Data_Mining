from bs4 import BeautifulSoup
import requests
import time
import random
import re


def html_data(url, user_agent_list, pages, keys, threads):

    users = {word: [] for word in keys}

    for i in range(1, pages):

        user_agent = random.choice(user_agent_list)

        headers = {'User-Agent': user_agent}

        html = requests.get(url, headers=headers)

        soup = BeautifulSoup(html.text, 'html.parser')

        title = []
        author = []
        comments = []
        scorelikes = []
        scoredislikes = []
        dates = []

        attrs = {'class': 'thing', 'data-domain': threads}

        for post in soup.find_all('div', attrs=attrs):

            try:
                title.append(post.find('p', class_='title').text)
            except Exception as e:
                title.append('Unknown')
                print(e)
            try:
                author.append(post.find('a', class_='author').text)
            except Exception as e:
                author.append('Unknown')
                print(e)
            try:
                comments.append(post.find('a', class_='comments').text.split()[0])
            except Exception as e:
                comments.append(0)
                print(e)
            try:
                scorelikes.append(post.find('div', attrs={'class': 'score likes'}).text)
            except Exception as e:
                scorelikes.append(0)
                print(e)
            try:
                scoredislikes.append(post.find('div', attrs={'class': 'score dislikes'}).text)
            except Exception as e:
                scoredislikes.append(0)
                print(e)
            try:
                dates.append(re.findall(r'\d{4}\-\d{2}\-\w+\:\d+\:\d+\+\d+',
                                        post.find('p', attrs={'class': 'tagline'}).time.prettify())[0])
            except Exception as e:
                dates.append('Unknown')
                print(e)

        users['title'] += title
        users['author'] += author
        users['comments'] += comments
        users['scorelikes'] += scorelikes
        users['scoredislikes'] += scoredislikes
        users['dates'] += dates

        try:
            next_button = soup.find('span', class_='next-button')
            url = next_button.find('a').attrs['href']
        except Exception as e:
            print(e)
            break

        time.sleep(2)

    return users